package com.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceRestApiProjectFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
