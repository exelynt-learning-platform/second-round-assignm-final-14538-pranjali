package com.ecommerce.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.User;

public interface CartRepository extends JpaRepository<Cart, Long> {
	
	Optional<Cart> findByUser(User user);
	
	boolean existsByUser(User user);
	
	void deleteByUser(User user);

}
